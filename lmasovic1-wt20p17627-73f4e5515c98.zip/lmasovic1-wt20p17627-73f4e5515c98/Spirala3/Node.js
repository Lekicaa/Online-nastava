const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require ('path');


app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 1')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 2')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 3')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 4')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 5')));
app.use(express.static(path.join(__dirname,'../Zadatak1')));
app.use(express.static(path.join(__dirname,'../Zadatak2')));


app.use(express.static(path.join(__dirname,'../Spirala1')));
app.use(express.static(path.join(__dirname, '../')));
app.get('/aktivnosti.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 2/aktivnost.html'));
});
app.get('/raspored.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 1/raspored.html'));
});
app.get('/planiranjeNastavnik.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 3/planiranjeNastavnik.html'));
});
app.get('/podaciStudent.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 4/podaciStudent.html'));
});
app.get('/meni.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 5/meni.html'));
});

app.get('/spirala2rasporedi.html',function(req,res)
{   res.sendFile(path.resolve('Zadatak 1/spirala2rasporedi.html'));
});





app.post('/predmet', function (req, res) {
     var body=req.body;
     fs.readFile(path.resolve('Spirala3/predmeti.txt'), function (err,data) {
         if(err) throw err;
         var p =data.toString('utf8');
         p=p.split("\n");
         
         var json =[];

         for(var j=0;j<p.length;j++)
         {
            if(p[j]!='')
            {
                if(p[j]==body.naziv)
                {
                    res.json({"message":"Naziv predmeta postoji!"});
                    return;
                } 
                
            }
         }

         var noviRed=body.naziv+"\n";
         fs.appendFile(path.resolve('Spirala3/predmeti.txt'),noviRed,function(err)
         {
             if(err) throw err;
             res.json({"message":"Uspješno dodan predmet!"});
         }
         );

        });
});


app.get('/predmeti', function (req, res) {

    fs.readFile(path.resolve('Spirala3/predmeti.txt'),function(err,data) {
        if(err)
        throw err;
        var p=data.toString('utf8');
        p=p.split('\n');
         var json=[];
        for(var j=0;j<p.length;j++)
         {
             var obj={};
             if(p[j]!='')
            {
                obj['naziv']=p[j];
                json.push(obj);
            }
         }
         res.json(json);
    });
    
    
});


app.post('/aktivnost', function (req, res) {
    var body=req.body;
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'), function (err,data) {
        if(err) 
        throw err;
        
        var a =data.toString('utf8');
         a=a.split("\n");

         for(var i=0;i<a.length;a++)
         {

            var temp=a[i].trim();
            var b=temp.split(',');
            
            if(b!='')
            {
                var naziv=b[0];
                var tip =b[1];
                var pocetak=b[2];
                var kraj=b[3];
                var dan=b[4];
                if(body.dan==dan ){
 if(pocetak <= body.pocetak && body.pocetak< kraj || body.kraj>pocetak && body.kraj<=kraj || pocetak>=body.pocetak && pocetak<body.kraj  || body.pocetak<0 || body.pocetak>24 || body.kraj<0 || body.kraj>24  || !(Number.isInteger(body.pocetak/0.5)) || !(Number.isInteger(body.kraj/0.5)))  
                 {
                    res.json({"message":"Aktivnost nije validna!"});
                    return;
                 }
            }
           }
        
        }

         var novaAktivnost=body.naziv + ',' + body.tip + ',' + body.pocetak + ',' + body.kraj+ ',' + body.dan + '\n';
         fs.appendFile(path.resolve('Spirala3/aktivnosti.txt'),novaAktivnost,function(err)
         {
             if(err) throw err;
             res.json({"message":"Uspješno dodana aktivnost!"});
         }
         );

   
   
    });

});

app.get('/aktivnosti', function (req, res) {
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'),function(err,data) {
        if(err)
        throw err;
        var p=data.toString('utf8');
        p=p.split('\n');
         var json=[];
        for(var i=0;i<p.length;i++)
         {
             var obj={};
             var temp=p[i].trim();
            var b=temp.split(',');
            obj['naziv']=b[0].trim();
            obj['tip']=b[1].trim();
            obj['pocetak']=b[2].trim();
            obj['kraj']=b[3].trim();
            obj['dan']=b[4].trim();
            json.push(obj);
         }
         res.json(json);
    });
        
});


app.get('/predmet/:naziv/aktivnost', function (req, res) {
    var naziv=req.params['naziv']
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'),function(err,data) {
        if(err)
        throw err;
        var p=data.toString('utf8');
        p=p.split('\n');
         var json=[];

        for(var i=0;i<p.length;i++)
         { var obj={};
         var temp=p[i].trim();
         var b=temp.split(',');
             if(naziv==b[0]){
            obj['naziv']=b[0].trim();
            obj['tip']=b[1].trim();
            obj['pocetak']=b[2].trim();
            obj['kraj']=b[3].trim();
            obj['dan']=b[4].trim();
            json.push(obj);
         }
        }
         res.json(json);
    });
    
});

app.delete('/aktivnost/:naziv', function (req, res) {

    var naziv=req.params['naziv'];
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'), function(err,data) {
         var  t=data.toString('utf8');
         var lines=t.split("\n");
        var temp=[];
        var ispravni='';
        
         for(var i=0;i<lines.length;i++)
         {
            if(lines[i].split(',')[0].trim()!= naziv && lines[i]!=''){
            temp.push(lines[i]);
            var aktivnost=lines[i].trim().split(',');
            ispravni+=aktivnost[0]+','+ aktivnost[1]+','+ aktivnost[2]+','+aktivnost[3]+','+aktivnost[4]+'\n';
            }
         }


         if(temp.length==lines.length) {
         res.json({"message":"Greška - aktivnost nije obrisana!"});
         return;
         }

         fs.writeFile(path.resolve('Spirala3/aktivnosti.txt'),ispravni,function(err)
         {
             if(err) throw err;
             

         });

         res.json({"message":"Uspješno obrisana aktivnost!"});

        });

});

app.delete('/predmet/:naziv', function (req, res) {
    var naziv=req.params['naziv'];
    fs.readFile(path.resolve('Spirala3/predmeti.txt'), function(err,data) {
         var  t=data.toString('utf8');
         var lines=t.split("\n");
        var temp=[];
        var ispravni='';
        
         for(var i=0;i<lines.length;i++)
         {
            if(lines[i].trim()!= naziv && lines[i]!=''){
            temp.push(lines[i]);
            ispravni+=lines[i].trim()+'\n';

            }
         }
         if(temp.length==lines.length) {
         res.json({"message":"Greška - predmet nije obrisan!"});
         return;
         }

         fs.writeFile(path.resolve('Spirala3/predmeti.txt'),ispravni,function(err)
         {
             if(err) throw err;
             

         });

         res.json({"message":"Uspješno obrisan predmet!"});

    });





});

app.delete('/all', function (req, res) {
    var json=[];

    fs.writeFile(path.resolve('Spirala3/predmeti.txt'),'',function(err) {
        if(err) 
        {
        res.json({"message":"Greška - sadržaj datoteka nije moguće obrisati!"});
        return;
        }
        
    });

    fs.writeFile(path.resolve('Spirala3/aktivnosti.txt'),'',function(err)
    {
        if(err) 
        {
        res.json({"message":"Greška - sadržaj datoteka nije moguće obrisati!"});
    return;
}
    });


        res.json({"message":"Uspješno obrisan sadržaj datoteka!"});

});

app.listen(3000);
