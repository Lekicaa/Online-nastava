const db = require("./db.js");
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require ('path');
const { aktivnost } = require("./db.js");
const { json } = require("sequelize/types");



app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 1')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 2')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 3')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 4')));
app.use(express.static(path.join(__dirname,'../Spirala1/Zadatak 5')));
app.use(express.static(path.join(__dirname,'../Zadatak1')));
app.use(express.static(path.join(__dirname,'../Zadatak2')));


app.use(express.static(path.join(__dirname,'../Spirala1')));
app.use(express.static(path.join(__dirname, '../')));
app.get('/aktivnosti.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 2/aktivnost.html'));
});
app.get('/raspored.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 1/raspored.html'));
});
app.get('/planiranjeNastavnik.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 3/planiranjeNastavnik.html'));
});
app.get('/podaciStudent.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 4/podaciStudent.html'));
});
app.get('/meni.html',function(req,res)
{   res.sendFile(path.resolve('Spirala1/Zadatak 5/meni.html'));
});

app.get('/spirala2rasporedi.html',function(req,res)
{   res.sendFile(path.resolve('Zadatak 1/spirala2rasporedi.html'));
});

//oznaceno /v1 su dijelovi sa prosle spirale oznace sa /v2 novi

app.post('/v2/predmet',function(req, res){
    db.predmet.findOne({where: {naziv:req.body.naziv}}).then(function (naziv) {
        if(naziv==null){
            db.predmet.create({naziv:req.body.naziv}).then(function (params) {
                res.json('Dodano');
            });
        }
        else{
            res.json("Vec ima");
        }
    });
});
app.post('/v2/dan',function(req, res){
    db.dan.findOne({where: {naziv:req.body.naziv}}).then(function (naziv) {
        if(naziv==null){
            db.dan.create({naziv:req.body.naziv}).then(function (params) {
                res.json('Dodano');
            });
        }
    });
});
app.post('/v2/tip',function(req, res){
    db.tip.findOne({where: {naziv:req.body.naziv}}).then(function (naziv) {
        if(naziv==null){
            db.tip.create({naziv:req.body.naziv}).then(function (params) {
                res.json('Dodato');
            });
        }
    });
});

app.post('/v2/grupa',function(req, res){
    db.grupa.findOne({where: {naziv:req.body.naziv}}).then(function (naziv) {
        if(naziv==null){
            db.predmet.findOne({where: {naziv:req.body.predmet.naziv}}).then(function (params) {
                if(params!=null)
                db.grupa.create({naziv:req.body.naziv}).then(function (nesto) {
                    params.setPredmetGrupe([nesto]).then(function (grupa) {
                        res.json('Dodana grupa');
                    });
                });
                else 
                {
                    res.json('Predmet ne postoji');
                }
                
            });
        }
        else 
        {
            res.json("Grupa vec postoji");
        }
    });
});

app.post('/v2/student',function(req, res){
    db.student.findOne({where: {naziv:req.body.naziv}}).then(function (naziv) {
        if(naziv==null){
            db.student.findOne({where: {index:req.body.index}}).then(function (params) {
                if(params!=null)
                {
                    db.grupa.create({index: req.body.index, naziv:req.body.naziv}).then(function (nesto) {
                        res.json("Dodan student");
                   });
                }
                else{
                    res.json("Student  nije kreiran jer postoji student" +req.body.naziv+req.body.index+"sa istim indexom" +req.body.inedex);
                }
                
            });
        }
    })
});


app.post('/v2/aktivnost',async(req, res)=>{
    if(req.body.pocetak<0 || req.body.pocetak>24 || req.body.kraj<0 || req.body.kraj>24  || !(Number.isInteger(req.body.pocetak/0.5)) || !(Number.isInteger(req.body.kraj/0.5))) 
 {
        res.json("Nije validno");
        
    var sveAktivnosti=await aktivnost.findAll({where: {danId:req.body.danId}});
    var postoji=false;
    for(var i=0;i<sveAktivnosti.length;i++)
     {
        var ak=aktivnosti[i];
        var p=aktivnost.pocetak;
        var k=aktivnost.kraj;
        if((p>=req.body.pocetak && k>=req.body.pocetak )||(p<=req.body.pocetak && k>=req.body.kraj)) postoji=true;
        res.json("Nije validna");
     }
 }
 if(postoji==false) {var novaA=await aktivnost.create(req.body);
return res.json(novaA);}
});

app.get('/v2/grupa',function (req,res) {
    db.grupa.findAll().then(function (grupe) {
        var niz=[];
        for(var i=0;i<grupe.length;i++)
        {
            niz.push(grupe[i]);
        }
    res.json(niz);
    });
});
app.get('/v2/tip',function (req,res) {
    db.tip.findAll().then(function (tipovi) {
        var niz=[];
        for(var i=0;i<tipovi.length;i++)
        {
            niz.push(tipovi[i]);
        }
    res.json(niz);
    });
});

app.get('/v2/dan',function (req,res) {
    db.dan.findAll().then(function (dani) {
        var niz=[];
        for(var i=0;i<dani.length;i++)
        {
            niz.push(dani[i]);
        }
    res.json(niz);
    });
});

app.get('/v2/predmet',function (req,res) {
    db.predmet.findAll().then(function (predmeti) {
        var niz=[];
        for(var i=0;i<predmeti.length;i++)
        {
            niz.push(predmeti[i]);
        }
    res.json(niz);
    });
});

app.get('/v2/student',function (req,res) {
    db.student.findAll().then(function (studenti) {
        var niz=[];
        for(var i=0;i<studenti.length;i++)
        {
            niz.push(studenti[i]);
        }
    res.json(niz);
    });
});

app.delete('/v2/grupa/:id',function (req,res) {
    db.grupa.findOne({where:{id:req.params.id}}).then(function (grupe) {
        if(grupe){
        grupe.destroy();
        res.json('Obrisano uspesno');
        return;
        }
        else{
            res.json("Greska pri brisanju");
        }
    });
});
app.delete('/v2/dan/:id',function (req,res) {
    db.dan.findOne({where:{id:req.params.id}}).then(function (dani) {
        if(dani){
        dani.destroy();
        res.json('Obrisano uspesno');
        return;
        }
        else
        {
            res.json("Greska pri brisanju");
        }
    });
});
app.delete('/v2/tip/:id',function (req,res) {
    db.tip.findOne({where:{id:req.params.id}}).then(function (tipovi) {
        if(tipovi){
        tipovi.destroy();
        res.json('Obrisano uspesno');
        return;
        }
        else{
            res.json("Greska pri brisanju");
        }
    });
});
app.delete('/v2/predmet/:id',function (req,res) {
    db.predmet.findOne({where:{id:req.params.id}}).then(function (predmeti) {
        if(predmeti){
        predmeti.destroy();
        res.json('Obrisano uspesno');
        return;
        }
        else{
            res.json("Greska pri brisanju");
        }
    });
});

app.delete('/v2/aktivnost/:id',function (req,res) {
    db.aktivnost.findOne({where:{id:req.params.id}}).then(function (aktivnost) {
        if(aktivnosti){
        aktivnosti.destroy();
        res.json('Obrisano uspesno');
        return;
        }
        else 
        {
            res.json("Greska pri brisanju");
        }
    });
    
});

app.delete('/v2/student/:id',function (req,res) {
    db.student.findOne({where:{id:req.params.id}}).then(function (studenti) {
        if(studenti){
        studenti.destroy().then(function (params) {
            res.json('Obrisano uspesno');
        return;
            
        });
    }
    else{
        res.json("Greska pri brisanju");
    }
    });
   
});


app.put('/v2/student/:id',function (req,res) {
    db.student.findOne({where:{index:req.body.index}}).then(function (student) {   
    if(student){
        if(student.dataValue.id=req.params.id){
    db.student.update(req.body,{where:{id:req.params.id}}).then(function (studenti) {
        if(studenti[0]==1)
         {
            res.json("Azuriran student");
            return;
        }
        else{
            res.json("Nevalidno");
        }
    });
    }
    }
        else{
            res.json("Ne ide");
        }
    });
});

app.put('/v2/predmet/:id',function (req,res) {
    db.predmet.findOne({where:{naziv:req.body.naziv}}).then(function (predmet) {   
    if(predmet){
    db.student.update(req.body,{where:{id:req.params.id}}).then(function (predmeti) {
        if(studenti)
        {
            res.json("Azuriran predmet");
            return;
        }
        else{
            res.json("Nevalidno");
        }
    });
    }
        else{
            res.json("Ne ide");
        }
    });
});

app.put('/v2/grupa/:id',function (req,res) {
    db.grupa.findOne({where:{naziv:req.body.naziv}}).then(function (grupa) {   
    if(grupa)
    {
        if(grupa.dataValue.id=req.params.is)
        {
            db.grupa.update(req.body,{where:{id:req.params.id}}).then(function (upgrupa) {
                if(upgrupa)
                {
                    res.json("update gotov");
                    return;
                }
                else{
                    res.json("Greska");
                }
            }).catch(function (err) {
                if(err) res.json("Nije validan id");
                return;
                
            });
        }
    }
});
});

app.put('/v2/dan/:id',function (req,res) {
    db.dan.update(req.body,{where:{id:req.params.id}}).then(function (dani) {
        if(dani[0]==1)
        {
            res.json("Uspesno");
            return;
        }

        else{res.json("Greska");}
    });
        
});


app.put('/v2/tip/:id',function (req,res) {
    db.tip.update(req.body,{where:{id:req.params.id}}).then(function (tipovi) {
        if(tipovi[0]==1)
        {
            res.json("Uspjesno");
            return;
        }
        else{res.json("Greska");}
    });
});

app.get('/v2/aktivnost',function (req,res) {
    db.aktivnost.findAll().then(function (aktivnosti) {
        var niz=[];
        for(var i=0;i<aktivnosti.length;i++)
        {
            niz.push(aktivnosti[i]);
        }
    res.json(niz);
    });
});



app.put('/v2/aktivnost',function (req,res) {
    
});


















app.post('/v1/predmet', function (req, res) {
     var body=req.body;
     fs.readFile(path.resolve('Spirala3/predmeti.txt'), function (err,data) {
         if(err) throw err;
         var p =data.toString('utf8');
         p=p.split("\n");
         
         var json =[];

         for(var j=0;j<p.length;j++)
         {
            if(p[j]!='')
            {
                if(p[j]==body.naziv)
                {
                    res.json({"message":"Naziv predmeta postoji!"});
                    return;
                } 
                
            }
         }

         var noviRed=body.naziv+"\n";
         fs.appendFile(path.resolve('Spirala3/predmeti.txt'),noviRed,function(err)
         {
             if(err) throw err;
             res.json({"message":"Uspješno dodan predmet!"});
         }
         );

        });
});


app.get('/v1/predmeti', function (req, res) {

    fs.readFile(path.resolve('Spirala3/predmeti.txt'),function(err,data) {
        if(err)
        throw err;
        var p=data.toString('utf8');
        p=p.split('\n');
         var json=[];
        for(var j=0;j<p.length;j++)
         {
             var obj={};
             if(p[j]!='')
            {
                obj['naziv']=p[j];
                json.push(obj);
            }
         }
         res.json(json);
    });
    
    
});


app.post('/v1/aktivnost', function (req, res) {
    var body=req.body;
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'), function (err,data) {
        if(err) 
        throw err;
        
        var a =data.toString('utf8');
         a=a.split("\n");

         for(var i=0;i<a.length;a++)
         {

            var temp=a[i].trim();
            var b=temp.split(',');
            
            if(b!='')
            {
                var naziv=b[0];
                var tip =b[1];
                var pocetak=b[2];
                var kraj=b[3];
                var dan=b[4];
                if(body.dan==dan ){
 if(pocetak <= body.pocetak && body.pocetak< kraj || body.kraj>pocetak && body.kraj<=kraj || pocetak>=body.pocetak && pocetak<body.kraj  || body.pocetak<0 || body.pocetak>24 || body.kraj<0 || body.kraj>24  || !(Number.isInteger(body.pocetak/0.5)) || !(Number.isInteger(body.kraj/0.5)))  
                 {
                    res.json({"message":"Aktivnost nije validna!"});
                    return;
                 }
            }
           }
        
        }

         var novaAktivnost=body.naziv + ',' + body.tip + ',' + body.pocetak + ',' + body.kraj+ ',' + body.dan + '\n';
         fs.appendFile(path.resolve('Spirala3/aktivnosti.txt'),novaAktivnost,function(err)
         {
             if(err) throw err;
             res.json({"message":"Uspješno dodana aktivnost!"});
         }
         );

   
   
    });

});

app.get('/v1/aktivnosti', function (req, res) {
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'),function(err,data) {
        if(err)
        throw err;
        var p=data.toString('utf8');
        p=p.split('\n');
         var json=[];
        for(var i=0;i<p.length;i++)
         {
             var obj={};
             var temp=p[i].trim();
            var b=temp.split(',');
            obj['naziv']=b[0].trim();
            obj['tip']=b[1].trim();
            obj['pocetak']=b[2].trim();
            obj['kraj']=b[3].trim();
            obj['dan']=b[4].trim();
            json.push(obj);
         }
         res.json(json);
    });
        
});


app.get('/v1/predmet/:naziv/aktivnost', function (req, res) {
    var naziv=req.params['naziv']
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'),function(err,data) {
        if(err)
        throw err;
        var p=data.toString('utf8');
        p=p.split('\n');
         var json=[];

        for(var i=0;i<p.length;i++)
         { var obj={};
         var temp=p[i].trim();
         var b=temp.split(',');
             if(naziv==b[0]){
            obj['naziv']=b[0].trim();
            obj['tip']=b[1].trim();
            obj['pocetak']=b[2].trim();
            obj['kraj']=b[3].trim();
            obj['dan']=b[4].trim();
            json.push(obj);
         }
        }
         res.json(json);
    });
    
});

app.delete('/v1/aktivnost/:naziv', function (req, res) {

    var naziv=req.params['naziv'];
    fs.readFile(path.resolve('Spirala3/aktivnosti.txt'), function(err,data) {
         var  t=data.toString('utf8');
         var lines=t.split("\n");
        var temp=[];
        var ispravni='';
        
         for(var i=0;i<lines.length;i++)
         {
            if(lines[i].split(',')[0].trim()!= naziv && lines[i]!=''){
            temp.push(lines[i]);
            var aktivnost=lines[i].trim().split(',');
            ispravni+=aktivnost[0]+','+ aktivnost[1]+','+ aktivnost[2]+','+aktivnost[3]+','+aktivnost[4]+'\n';
            }
         }


         if(temp.length==lines.length) {
         res.json({"message":"Greška - aktivnost nije obrisana!"});
         return;
         }

         fs.writeFile(path.resolve('Spirala3/aktivnosti.txt'),ispravni,function(err)
         {
             if(err) throw err;
             

         });

         res.json({"message":"Uspješno obrisana aktivnost!"});

        });

});

app.delete('/v1/predmet/:naziv', function (req, res) {
    var naziv=req.params['naziv'];
    fs.readFile(path.resolve('Spirala3/predmeti.txt'), function(err,data) {
         var  t=data.toString('utf8');
         var lines=t.split("\n");
        var temp=[];
        var ispravni='';
        
         for(var i=0;i<lines.length;i++)
         {
            if(lines[i].trim()!= naziv && lines[i]!=''){
            temp.push(lines[i]);
            ispravni+=lines[i].trim()+'\n';

            }
         }
         if(temp.length==lines.length) {
         res.json({"message":"Greška - predmet nije obrisan!"});
         return;
         }

         fs.writeFile(path.resolve('Spirala3/predmeti.txt'),ispravni,function(err)
         {
             if(err) throw err;
             

         });

         res.json({"message":"Uspješno obrisan predmet!"});

    });





});

app.delete('/v1/all', function (req, res) {
    var json=[];

    fs.writeFile(path.resolve('Spirala3/predmeti.txt'),'',function(err) {
        if(err) 
        {
        res.json({"message":"Greška - sadržaj datoteka nije moguće obrisati!"});
        return;
        }
        
    });

    fs.writeFile(path.resolve('Spirala3/aktivnosti.txt'),'',function(err)
    {
        if(err) 
        {
        res.json({"message":"Greška - sadržaj datoteka nije moguće obrisati!"});
    return;
}
    });


        res.json({"message":"Uspješno obrisan sadržaj datoteka!"});

});





app.listen(3000);
