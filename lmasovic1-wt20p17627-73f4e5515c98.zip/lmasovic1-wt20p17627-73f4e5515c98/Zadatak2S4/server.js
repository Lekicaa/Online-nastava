//const { grupa } = require("../db.js");
//const db = require("./db.js");

function Student() {
    var redovi = document.getElementById('unesi').value.split('\n');
    textvalue="";
    for(var i=0;i<redovi.lenght();i++)
    {
        var studentipodaci=redovi[i].spli(',');
        var ime=studentipodaci[0];
        var ind=studentipodaci[1];
        var student={ ime:ime, index:ind };
    }
   var ajax=new XMLHttpRequest();
   ajax.open("GET", "http://localhost:3000/v2/student", true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
             
            var nizstudenata = JSON.parse(this.responseText);

            for(var i=0;i<nizstudenata.lenght;i++)
            {


                //postoji
                    ajaxS=new XMLHttpRequest(); 
                    ajaxS.onreadystatechange = function() {
                     if (ajaxS.readyState == 4 && ajaxS.status == 200) {
                     
                        textarea.value+="Student  nije kreiran jer postoji student" +ime+index+"sa istim indexom" +inedex +"\n";
                     }
                     
                    }
                    ajaxS.open("POST", "http://localhost:3000/student", true);
          
                  }
    ajaxS.send(JSON.stringify(student));
}
}}  

function Grupe()
{
    var grupice=new XMLHttpRequest();
    grupice.open("GET", "https://localhost:3000/v2/grupa", true); 
    grupice.onreadystatechange = function() {
   if (grupice.readyState == 4 && grupice.status == 200) {
     var grup=JSON.parse(grupice.responseText);
     var dobgrupe=document.getElementById("grupa");
     for(i=0;i<grupa.lenght;i++)
     {
        var value=document.createElement("option");
        var textvalue=document.createTextNode(grupa[i].naziv);
        value.appendChild(textvalue);
        dobgrupe.appendChild(value);
     }
     }
    }
    grupice.send();
}




/*var xhttp = new XMLHttpRequest();
xhttp.open("POST", "http://localhost:3000/student", true); 
xhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200) {
     // Response
     var response = this.responseText;
   }
};

var data = {name:'LEjla',index:'17627'};
xhttp.send(JSON.stringify(data));------pravi json podatak od js objekta*/