Server pokrecem preko komande node Spirala3/Node.js



