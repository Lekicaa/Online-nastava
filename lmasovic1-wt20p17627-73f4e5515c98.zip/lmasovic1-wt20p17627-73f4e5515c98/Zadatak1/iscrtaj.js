function iscrtajRaspored(div, dani, satPocetak, satKraj) {
    if (satPocetak > satKraj || (satPocetak < 0 || satPocetak > 24) || (satKraj < 0 || satPocetak > 24)) {
        div.innerText = "Greska";
    }
    else {
        var tabela = document.createElement("table");
        var red = document.createElement("tr");
        var sati = [];
        for (let s = 0; s < 12; s++) {
            if (satPocetak <= [0, 2, 4, 6, 8, 10, 12, 15, 17, 19, 21, 23][s] && [0, 2, 4, 6, 8, 10, 12, 15, 17, 19, 21, 23][s] <= satKraj) {
                sati.push([0, 2, 4, 6, 8, 10, 12, 15, 17, 19, 21, 23][s]);
            }
        }

        sati.pop();

        for (var j = satPocetak; j <= satKraj; j += 0.5) {
            red.setAttribute("id", "brojevi");
            var celija = document.createElement("td");

            if (sati.includes(j)) {
                var text = "";
                text = document.createTextNode(j.toString().padStart(2, "0") + ":" + "00");
                celija.appendChild(text);
                celija.setAttribute("colspan", "2");
                j += 0.5;

            }

            red.appendChild(celija);
        }

        tabela.appendChild(red);

        for (var i = 1; i <= dani.length; i++) {
            var red = document.createElement("tr");
            red.classList.add(dani[i - 1].toString())
            for (var k = satPocetak; k <= (satKraj); k += 0.5) {
                if (k == satPocetak) {
                    celija = document.createElement("th");
                    var text = "";
                    text = document.createTextNode(dani[i - 1].toString());
                    celija.appendChild(text);
                    celija.classList.add("dan");
                }
                else {
                    var celija = document.createElement("td");
                }
                red.appendChild(celija);

            }

            tabela.appendChild(red);
        }

        let grupa = document.createElement("colgroup");

        for (var i = satPocetak; i <= satKraj; i += 0.5) {
            kolona = document.createElement("col");
            if (i == satPocetak) {
                kolona.style.borderLeft = "solid 1px black";
            }
            else if (i == satKraj) {
                kolona.style.borderRight = "solid 1px black";
            }
            else if (i % 2 == 1.5 || i % 2 == 0.5) {
                kolona.style.borderRight = "dashed 1px black";
            }
            else {
                kolona.style.borderRight = "solid 1px black";
            }

            grupa.appendChild(kolona);
        }

        tabela.appendChild(grupa);
    }

    div.appendChild(tabela);
}


function dodajAktivnost(raspored, naziv, tip, vrijemePocetak, vrijemeKraj, dan) {
    if (!provjeriParametre(raspored, vrijemePocetak, vrijemeKraj, dan)) {
        return;
    }

    if (raspored == null) {
        alert("Greska-Raspored nije kreiran");
    }

    var trajanje = vrijemeKraj - vrijemePocetak;
    var dan = document.getElementsByClassName(dan)[0];
    let red = dan.getElementsByTagName("td");
    let satiRed = document.getElementById("brojevi");
    let satiKolone = satiRed.getElementsByTagName("td");
    let pocetak = parseInt(satiKolone[0].innerText);

    for (var i = pocetak; i <= pocetak + (red.length / 2); i += 0.5) {
        if (i == vrijemePocetak) {
            if (proveriZauzete(red, (i - pocetak) * 2, (i - pocetak) * 2 + trajanje * 2)) {
                var predmet = document.createElement("div");
                var akt = document.createElement("div");
                predmet.innerText = naziv;
                akt.innerText = tip;
                predmet.classList.add("naziv");
                akt.classList.add("tip");

                var sirina = 0;
                var zauzetaAktivnost = document.createElement("div");
                zauzetaAktivnost.appendChild(predmet);
                zauzetaAktivnost.appendChild(akt);
                zauzetaAktivnost.classList.add("aktivnost");

                red[(i - pocetak) * 2].appendChild(zauzetaAktivnost);
                var zadnji = (i - pocetak) * 2;

                for (var j = (i - pocetak) * 2; j < (i - pocetak) * 2 + trajanje * 2; j++) {
                    red[j].classList.add("zauzeto");

                    sirina += 25;
                    zadnji++;
                }
                zauzetaAktivnost.style.borderRight = (i + trajanje) % 1 === 0.5 ? "dashed 1px black" : "solid 1px black";
                zauzetaAktivnost.style.width = sirina - 2 + "px";
            }
            else {
                alert("Greška - već postoji termin u rasporedu u zadanom vremenu");
            }
        }
    }
}

function proveriZauzete(red, pocetak, kraj) {


    for (var i = pocetak; i < kraj; i++) {
        if (red[i].classList.contains("zauzeto"))
            return false;
    }
    return true;
}

function provjeriParametre(raspored, vrijemePocetak, vrijemeKraj, dan) {
    if (vrijemeKraj < vrijemePocetak || vrijemePocetak < 0 || vrijemePocetak > 24 || vrijemeKraj < 0 || vrijemeKraj > 24
        || !(vrijemePocetak % 1 == 0.5 || vrijemePocetak % 1 == 0 || vrijemeKraj % 1 == 0.5 || vrijemeKraj % 1 == 0)) {


        alert("Greska za vrijeme");
    }
    var mojiDani = raspored.getElementsByClassName("dan");

    var imaDan = false;
    for (var j = 0; j < mojiDani.length; j++) {

        if (mojiDani[j].innerText == dan) {
            imaDan = true;
            break;

        }

    }
    if (!imaDan) { alert("Greška - u rasporedu ne postoji dan ili vrijeme u kojem pokušavate dodati termin"); return false; }
    return true;


}