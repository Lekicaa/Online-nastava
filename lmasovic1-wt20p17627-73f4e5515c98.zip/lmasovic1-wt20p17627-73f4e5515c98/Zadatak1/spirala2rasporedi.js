function Callme()
{
    let div=document.getElementById("prvi");
    let div2=document.getElementById("drugi");

    Iscrtaj.iscrtajRaspored(div,["Ponedjeljak","Utorak","Srijeda"],8,21);
    Iscrtaj.dodajAktivnost(div,"OIS","predavanje",10.5,12,"Ponedjeljak");
    Iscrtaj.dodajAktivnost(div,"OOI","predavanje",12,16,"Utorak");
    Iscrtaj.dodajAktivnost(div,"RG","vjezbe",16,17.5,"Utorak");
    Iscrtaj.dodajAktivnost(div,"WT","predavanje",9,12,"Srijeda"); 



    Iscrtaj.iscrtajRaspored(div2,["Ponedjeljak","Srijeda","Petak"],8,18);
    Iscrtaj.dodajAktivnost(div2,"OOI","predavanje",8,10,"Ponedjeljak");
    Iscrtaj.dodajAktivnost(div2,"DM","predavanje",12,16,"Srijeda");
    Iscrtaj.dodajAktivnost(div2,"ASP","predavanje",10,12,"Petak");
    Iscrtaj.dodajAktivnost(div2,"WT","vjezbe",10,12,"Ponedjeljak");
}


