const Sequelize = require("sequelize");
const sequelize = new Sequelize("wt2017627","root","",{
    host:"localhost",
    dialect:"mysql",
    logging:false,
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
      }
});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.predmet = require('./predmet.js')(sequelize, Sequelize.DataTypes);
db.grupa = require(__dirname+'/grupa.js')(sequelize, Sequelize.DataTypes);
db.aktivnost = require(__dirname+'/aktivnost.js')(sequelize, Sequelize.DataTypes);
db.dan = require(__dirname+'/dan.js')(sequelize, Sequelize.DataTypes); 
db.tip = require(__dirname+'/tip.js')(sequelize, Sequelize.DataTypes);  
db.student = require(__dirname+'/student.js')(sequelize, Sequelize.DataTypes); 

//relacije   Predmet 1-N Grupa
db.predmet.hasMany(db.grupa,{as:'predmetGrupe'});

//Aktivnost N-1 Predmet
db.predmet.hasMany(db.aktivnost,{as:'predmetAktivnosti',foreignKey:{allowNull:false}});
//Aktivnost N-0 Grupa
db.grupa.hasMany(db.aktivnost,{as:'grupaAktivnost',foreignKey:{allowNull:true}});
//Aktivnost N-1 Dan  u jednom danu vise aktivnosti
db.dan.hasMany(db.aktivnost,{as:'danAktivnosti',foreignKey:{allowNull:false}});
//Aktivnost N-1 Tip
db.tip.hasMany(db.aktivnost,{as:'tipAktivnosti',foreignKey:{allowNull:false}});

//student-- više na više --grupa 
db.studentGrupa=db.grupa.belongsToMany(db.student,{as:'studenti',through:'student_grupa',foreignKey:'idgrupa'});
db.student.belongsToMany(db.grupa,{as:'grupe',through:'student_grupa',foreignKey:'idstudent'});


module.exports=db;