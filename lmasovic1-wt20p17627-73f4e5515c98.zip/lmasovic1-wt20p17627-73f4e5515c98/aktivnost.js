const Sequelize = require("sequelize");

module.exports = function(sequelize,DataTypes){
    const Aktivnost = sequelize.define("aktivnost",{
        naziv:{
            type:Sequelize.STRING
        },
        pocetak:{
            type:Sequelize.FLOAT,
           
        },
        kraj:{
            type:Sequelize.FLOAT,
        }
    });
    return Aktivnost;
};