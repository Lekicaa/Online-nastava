db.sequelize.sync({force:true}).then(function (params) {
    inicijaliz().then(function (params) {
        
        
    })
    
});


function inicijaliz()
{
    
}